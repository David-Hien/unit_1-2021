Some puzzles are not easy to figure out, if you feel stuck, read the solution below.
Spoilers!!!

Chapter 2:
 - To unlock the basement door, go to the clock.
 - It should say 23:58, wait 10 seconds.
 - When the clock turns 23:59, the door will unlock.

Chapter 3:
 - Go to the basement door, it will trigger the bathroom door to creak open.
 - Go to the bathroom door and finish the sequence.
 - The basement door will open.

Chapter 4:
 - Go to the radio, it will say a code "40128" in a deep voice.
 - Dial the code into the phone, the bathroom door will open.
 - After the door opens, you will start to hear footsteps.
 - You have 30 seconds to go into the bathroom and hide.
 - Once the footsteps get further, you will hear a door open, that's the exit.

Congratulations! You beat the demo!